import { signup } from "./signup";
import { login, logout } from "./login";

// SIGN UP FORM

const signupForm = document.querySelector(".form--signup");

if (signupForm) {
  signupForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const passwordConfirm = document.getElementById("passwordConfirm").value;

    const btn = signupForm.querySelector("button");
    const originalText = btn.textContent;

    try {
      btn.textContent = "Loading...";
      btn.disabled = true;

      await signup(name, email, password, passwordConfirm);
    } catch (err) {
      console.error(err);
    } finally {
      btn.textContent = originalText;
      btn.disabled = false;
    }
  });
}


// LOGIN FORM

const loginForm = document.querySelector(".form--login");

if (loginForm) {
  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    const btn = loginForm.querySelector("button");
    const originalText = btn.textContent;

    try {
      btn.textContent = "loading...";
      btn.disabled = true;

      await login(email, password);
    } catch (err) {
      console.error( err);
    } finally {
      btn.textContent = originalText;
      btn.disabled = false;
    }
  });
}


// LOGOUT BUTTON

const logoutBtn = document.querySelector(".nav__el--logout");

if (logoutBtn) {
  logoutBtn.addEventListener("click", (e) => {
    e.preventDefault();
    logout();
  });
}

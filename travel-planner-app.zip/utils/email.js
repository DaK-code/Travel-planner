const nodemailer = require("nodemailer");
const htmlToText = require("html-to-text");

module.exports = class Email {
  constructor(user, url) {
    this.to = user.email;
    this.firstName = user.name.split(" ")[0];
    this.url = url;
    this.from = `Travel Planner <${process.env.EMAIL_FROM}>`;
  }

  newTransport() {
    if (process.env.NODE_ENV === "production") {
      // SendGrid in production
      return nodemailer.createTransport({
        service: "SendGrid",
        auth: {
          user: process.env.SENDGRID_USERNAME,
          pass: process.env.SENDGRID_PASSWORD,
        },
      });
    }

   
    return nodemailer.createTransport({
      host: process.env.EMAIL_HOST,
      port: Number(process.env.EMAIL_PORT),
      auth: {
        user: process.env.EMAIL_USERNAME,
        pass: process.env.EMAIL_PASSWORD,
      },
    });
  }

  // Render and send email
  async send(subject, html) {
    const mailOptions = {
      from: this.from,
      to: this.to,
      subject,
      html,
      text: htmlToText.convert(html),
    };

    await this.newTransport().sendMail(mailOptions);
  }

  async sendWelcome() {
    const html = `
      <div>
        <h1>Welcome to Travel Planner, ${this.firstName}!</h1>
        <p>Thank you for joining the Travel Planner family.</p>
        <p>Your account has been successfully created.</p>
        <p>
          <a href="${this.url}">Visit your account</a>
        </p>
        <p>We hope you enjoy Travel Planner!</p>
        <p>
          See you soon,<br>
          The Travel Planner Team
        </p>
      </div>
    `;

    await this.send("Welcome to the Travel Planner Family!", html);
  }

  async sendPasswordReset() {
    const html = `
      <div>
        <h1>Password Reset</h1>
        <p>Hello ${this.firstName},</p>
        <p>You requested a password reset.</p>
        <p>This reset token is valid for only 10 minutes.</p>
        <p>
          <a href="${this.url}">Reset your password</a>
        </p>
        <p>If you did not request this, please ignore this email.</p>
        <p>The Travel Planner Team</p>
      </div>
    `;

    await this.send(
      "Your password reset token (valid for only 10 minutes)",
      html,
    );
  }
};

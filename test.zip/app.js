const path = require("path");
const express = require("express");
const morgan = require("morgan");
const rateLimit = require("express-rate-limit");
const helmet = require("helmet");
const mongoSanitize = require("express-mongo-sanitize");
const cookieParser = require("cookie-parser"); // 👈 Ajouté

const reviewRouter = require("./routes/reviewRoutes");
const bookingRouter = require("./routes/bookingRoutes");
const userRouter = require("./routes/userRoutes");
const tourRouter = require("./routes/tourRoutes");
const viewRouter = require("./routes/viewRoutes");
const AppError = require("./utils/appError");
const globalErrorHandler = require("./controllers/errorController");

const app = express();

// 1) GLOBAL MIDDLEWARES

// Moteur de rendu Pug
app.set("view engine", "pug");
app.set("views", path.join(__dirname, "views"));

// Fichiers statiques
app.use(express.static(path.join(__dirname, "public")));

// Headers de sécurité HTTP
app.use(helmet({ contentSecurityPolicy: false })); // Désactivé temporairement CSP pour charger Mapbox/images sans blocage

// Logging en dev
if (process.env.NODE_ENV === "development") {
  app.use(morgan("dev"));
}

// Rate limiting
const limiter = rateLimit({
  max: 100,
  windowMs: 60 * 60 * 1000,
  message: "Too many requests from this IP, please try again in an hour!",
});
app.use("/api", limiter);

// Body parser
app.use(express.json({ limit: "10kb" }));
app.use(express.urlencoded({ extended: true, limit: "10kb" })); // 👈 Permet de lire les formulaires HTML
app.use(cookieParser()); // 👈 Nécessaire pour l'authentification côté View

// Sanitization NoSQL
app.use((req, res, next) => {
  if (req.body) mongoSanitize.sanitize(req.body);
  if (req.params) mongoSanitize.sanitize(req.params);
  next();
});

// 2) ROUTES
app.use("/", viewRouter); // 👈 Placé en premier pour servir le site web
app.use("/api/v1/tours", tourRouter);
app.use("/api/v1/users", userRouter);
app.use("/api/v1/reviews", reviewRouter);
app.use("/api/v1/bookings", bookingRouter);

// 3) GESTION DES ROUTES INEXISTANTES (404)
app.all(/.*/, (req, res, next) => {
  // 👈 Regex universelle propre
  next(new AppError(`Can't find ${req.originalUrl} on this server!`, 404));
});

// 4) GESTIONNAIRE D'ERREURS GLOBAL
app.use(globalErrorHandler);

module.exports = app;

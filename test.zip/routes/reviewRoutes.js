const express = require("express");
const reviewController = require("../controllers/reviewController");
const authController = require("../controllers/authController");

// mergeParams: true permet d'accéder aux paramètres des routes parentes (ex: /tours/:tourId/reviews)
const router = express.Router({ mergeParams: true });

router.use(authController.protect);

router
  .route("/")
  .get(reviewController.getAllReviews)
  .post(
    authController.restrictTo("user"),
    reviewController.setTourUserIds,
    reviewController.createReview,
  );

router
  .route("/:id")
  .delete(
    authController.restrictTo("user", "admin"),
    reviewController.deleteReview,
  );

module.exports = router;
